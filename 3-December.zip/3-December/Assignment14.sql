use TrainingDb
select * from employee
delete from employee where empno=7060

--Create a Stored Procedure that will accept the DeptName as 
--Input parameter and returns list of Employees for the DeptName.
--------------------------------------------------------------------------------------------------------
 --Create a stored procedure performs Insert operations for multiple employees. 
-->
create procedure insertdata(@empno int,@empname varchar(20),@salary int,@deptno int)
as
begin
insert into employee(empno,empname,salary,deptno) values(@empno,@empname,@salary,@deptno)
end

execute dbo.insertdata 7060,'Praju',30000,2
---------------------------------------------------------------------------------------------------------

--Create a Stored Procedute that will list  Employee having Max Salary per department.
alter procedure listEmp
as
begin
select max(salary) as MaxSalary,department.deptno from employee inner join department on employee.deptno=department.deptno
group by department.deptno
end

execute dbo.listEmp
------------------------------------------------------------------------------------------------------------------------
 
--Create a Stored Procedure that will calculate Tax for each employee as 0.05% of salary ans list all employees. 
--->
create procedure calculatesal
as
begin
select empname,(salary/100)*5 as tax from employee
end

execute dbo.calculatesal