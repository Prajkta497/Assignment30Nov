﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assignment15
{
   // Execute Stored Procedures created above using ADP.NET.
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=PRAGMASYS-PC94\\MSSQLSERVER001;Initial Catalog=TrainingDb;Integrated Security=True");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("ShowAllData", con);
           cmd.CommandType=  CommandType.StoredProcedure;
            con.Open();
           dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("InserData",con);
            cmd.Parameters.AddWithValue("@deptno",textBox1.Text);
            cmd.Parameters.AddWithValue("@deptname",textBox2.Text);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("data is inserted...");
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("listEmp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("calculatesal", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.Close();

        }
    }
}
