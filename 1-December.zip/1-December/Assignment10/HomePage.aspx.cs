﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HomePage : System.Web.UI.Page
{
 //Create a Currency Converter User Control in ASP.NET web forms.
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        float val = float.Parse(TextBox2.Text);
        float cur =float.Parse( DropDownList1.SelectedValue.ToString());

        float result = val * cur;
        Label1.Text = val.ToString();
        Label2.Text = result.ToString();
    }
}