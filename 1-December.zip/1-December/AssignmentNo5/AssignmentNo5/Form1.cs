﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AssignmentNo5
{
    public partial class Form1 : Form
    {
   //Create windform application that provides the SCIENTIFIC Calcluator funcationality.
        double firstno = 0;

        string sign = "+";
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += button3.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += button4.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += button5.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += button6.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += button7.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += button8.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += button9.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text += button10.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text += button11.Text;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            sign = "+";
            firstno = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            sign = "-";
            firstno = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "";
        }

        private void button19_Click(object sender, EventArgs e)
        {
            sign = "*";
            firstno = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "";
        }

        private void button20_Click(object sender, EventArgs e)
        {
            sign = "/";
            firstno = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            double secno;
            double res = 0;
            secno = Convert.ToDouble(textBox1.Text);
            if (sign == "+")
                res = firstno + secno;
            if (sign == "-")
                res = firstno - secno;
            if (sign == "*")
                res = firstno * secno;
            if (sign == "/")
                res = firstno / secno;
            textBox1.Text = res.ToString();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            firstno = Convert.ToDouble(textBox1.Text);
            double res = 0;
            res = Math.Sin(firstno);
            textBox1.Text = res.ToString();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            firstno = Convert.ToDouble(textBox1.Text);
            double res = 0;
            res = Math.Cos(firstno);
            textBox1.Text = res.ToString();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            firstno = Convert.ToDouble(textBox1.Text);
            double res = 0;
            res = Math.Tan(firstno);
            textBox1.Text = res.ToString();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            firstno = Convert.ToDouble(textBox1.Text);
            double res = 0;
            res = Math.Sqrt(firstno);
            textBox1.Text = res.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
    }
}
