﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
         public class Mainclass
        {
        public double NetBalance { get; set; }

        public void OverBalance()
            {
              Console.WriteLine("enter the amount");
              double amount =Convert.ToDouble( Console.ReadLine());
            double balance = 25000;
            NetBalance = amount + balance;
                if (NetBalance > 100000)
                {
                    double tax = amount * 0.18;
                    Console.Write(" \n Your tax amount is \n" + tax);
                    
                }
            }
            
            public void UnderBalace()
            {
                if (NetBalance < 5000)
                {
                    Console.WriteLine(" balance must be maintain as Rs. 5000");
                }
            }
        }

    }

   

