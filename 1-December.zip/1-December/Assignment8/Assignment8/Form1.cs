﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Assignment8
{
    public partial class Form1 : Form
    {
        //Create a WinForm applciatio that will Accept Employee Information from the user
        //    and this information will be saved in the Xml/Text files. 
        //        The WinForm application should read all recodrs of employees and 
        //        show on the RichTextBox.
        public Form1()
        {
            InitializeComponent();
        }

        FileStream st;
        XmlSerializer xml;
      
        StreamReader sr;
        private void button1_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.EmpID =Convert.ToInt32( textBox1.Text);
            emp.Empname = textBox2.Text;
            emp.Salary = Convert.ToInt32(textBox3.Text);
            st = new FileStream(@"C:\Users\test\Desktop\Study\demo1.txt",FileMode.Append,FileAccess.Write);
            xml = new XmlSerializer(typeof(Employee));

            xml.Serialize(st, emp);
            st.Close();
            MessageBox.Show("done..");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            st = new FileStream(@"C:\Users\test\Desktop\Study\demo1.txt", FileMode.Open, FileAccess.Read);
            sr = new StreamReader(st);
            richTextBox1.Text = sr.ReadToEnd().ToString();
            //xml = new XmlSerializer(typeof(Employee));

            //Employee emp1 = (Employee)xml.Deserialize(st);
            //st.Close();
            
           
            //richTextBox1.Text= emp1.EmpID.ToString();
            //richTextBox1.Text= emp1.Empname;
            //richTextBox1.Text= emp1.Salary.ToString();
            st.Close();

        }
    }
}
