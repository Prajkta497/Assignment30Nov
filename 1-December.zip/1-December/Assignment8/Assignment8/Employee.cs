﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
   public class Employee
    {
        public int EmpID { get; set; }
        public string Empname { get; set; }
        public int Salary { get; set; }
    }
}
