﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class EmployeeInfoAp : System.Web.UI.Page
{
  //Create a WebForm application, that will use ADO.NET Connected Architecture to accept Employee Information.
 //These employees must be shown in the GridView control. Implement the create,
 //read, update and delete oeprations using GridView. The GridView must sort the Employees the data based on Columns. 
  // e.g. EmpName, Salary, DeptName, Designation

    SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=PRAGMASYS-PC94\\MSSQLSERVER001;Initial Catalog=TrainingDb;Integrated Security=True");
    }

    protected void btn1_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("select * from EmployeeInfo", con);
        con.Open();
        dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        con.Close();
    }

    protected void btn2_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("insert into EmployeeInfo values(@empno,@empname,@salary,@dname,@desig)", con);
        cmd.Parameters.AddWithValue("@empno", TextBox1.Text);
        cmd.Parameters.AddWithValue("@empname", TextBox2.Text);
        cmd.Parameters.AddWithValue("@salary", TextBox3.Text);
        cmd.Parameters.AddWithValue("@dname", TextBox4.Text);
        cmd.Parameters.AddWithValue("@desig", TextBox5.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
    }

    protected void btn3_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("update EmployeeInfo set EmpName=@empname where EmpId=@empno", con);
        cmd.Parameters.AddWithValue("@empno", TextBox1.Text);
        cmd.Parameters.AddWithValue("@empname", TextBox2.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    
        TextBox1.Text = "";
        TextBox2.Text = "";
    }

    protected void btn4_Click(object sender, EventArgs e)
    {
        cmd = new SqlCommand("delete from EmployeeInfo where EmpId=@empid", con);
        cmd.Parameters.AddWithValue("@empid", TextBox1.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
 
        TextBox1.Text = "";
    }
}