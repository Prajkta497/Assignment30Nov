﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class Program
    {
        static void Main(string[] args)
        {
           //Create a Custom Control that will be used to change the Currency from Source to
          // target currency e.g. INR to USD (Use 10 currencies)

            Double usd, inr, val;
            // how many dpllars
            Console.WriteLine("enter the usd");
            usd =Convert.ToDouble( Console.ReadLine()) ;
            // current value of US$
            Console.WriteLine("enter the value");
            val = Convert.ToDouble(Console.ReadLine());
            inr = usd * val;
            Console.WriteLine("{0} Dollar = {1} INR", usd, inr);
        }
    }
}
